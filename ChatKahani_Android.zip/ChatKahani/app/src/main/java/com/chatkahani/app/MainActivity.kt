package com.chatkahani.app

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var llm: LlmInference? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val modelFile by lazy { File(filesDir, "model.task") }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) js("window.onModelReady(false)") else copyModel(uri)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.goBack()") { handled ->
                    if (handled != "true") finish()
                }
            }
        })
    }

    private fun js(code: String) = web.post { web.evaluateJavascript(code, null) }

    private fun copyModel(uri: Uri) {
        worker.execute {
            try {
                llm?.close(); llm = null
                contentResolver.openInputStream(uri)!!.use { input ->
                    modelFile.outputStream().use { out -> input.copyTo(out) }
                }
                // Load once now so a wrong file is caught immediately.
                engine()
                js("window.onModelReady(true)")
            } catch (e: Throwable) {
                modelFile.delete(); llm = null
                js("window.onModelReady(false)")
            }
        }
    }

    @Synchronized
    private fun engine(): LlmInference {
        llm?.let { return it }
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile.absolutePath)
            .setMaxTokens(1536)
            .build()
        return LlmInference.createFromOptions(this, opts).also { llm = it }
    }

    inner class Bridge {
        @JavascriptInterface
        fun hasModel(): Boolean = modelFile.exists() && modelFile.length() > 0

        @JavascriptInterface
        fun pickModel() { runOnUiThread { picker.launch(arrayOf("*/*")) } }

        @JavascriptInterface
        fun generate(id: Int, prompt: String) {
            worker.execute {
                try {
                    val text = engine().generateResponse(prompt)
                    js("window.onAiResult($id,${JSONObject.quote(text)},null)")
                } catch (e: Throwable) {
                    js("window.onAiResult($id,null,${JSONObject.quote(e.message ?: "error")})")
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        llm?.close(); llm = null
        worker.shutdown()
    }
}
